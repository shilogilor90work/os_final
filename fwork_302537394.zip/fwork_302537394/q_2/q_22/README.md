to compile please type from the correct directory:
make all

to run server:
./server

to run client:
./client <pid> <sigint(2)> <int as amount>
or
./client <pid> <siguser1(10)> <int as amount(1)>
